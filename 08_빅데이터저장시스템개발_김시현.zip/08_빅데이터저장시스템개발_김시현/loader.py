# =======================================================
# 08_빅데이터저장시스템개발_김시현/loader.py
#
# 수집한 결과로 나온 파일 OTT service_long.csv을
# 테이블에 적재
# =======================================================
import os 
import pandas as pd
from database import get_session
from models import OttUsage

BASE_DIR = os.getcwd()
INPUT_PATH = os.path.join(BASE_DIR, 'input', 'OTT service_long.csv')

def load_from_csv(path: str=INPUT_PATH) -> dict:
    df = pd.read_csv(path, encoding='utf-8-sig')

    df.columns =df.columns.str.strip().str.replace(r'\(.*\)', '', regex=True).str.replace('%', '')
    df['사례수'] = pd.to_numeric(df['사례수'], errors='coerce')
    df['이용비율'] = pd.to_numeric(df['이용비율'], errors='coerce')

    db = get_session()
    success = 0
    failed = 0

    for _, row in df.iterrows():
        try:
            ott_type_val = None
            for key in ['OTT_분류', 'OTT분류', 'OTT 분류', 'OTT서비스_분류', 'OTT서비스분류']:
                if key in row and pd.notna(row[key]):
                    ott_type_val = str(row[key])
                    break
            
            age_class_val = None
            for key in ['연령별_분류', '연령별분류', '연령별 분류', '연령대_분류', '연령대분류']:
                if key in row and pd.notna(row[key]):
                    age_class_val = str(row[key])
                    break

            ott_data = OttUsage(
                연도 = str(row['연도']) if pd.notna(row.get('연도')) else None,
                성별 = str(row['성별']) if pd.notna(row.get('성별')) else None,
                연령대 = str(row['연령대']) if pd.notna(row.get('연령대')) else None,
                사례수 = int(row['사례수']) if pd.notna(row.get('사례수')) else 0,
                OTT서비스 = str(row['OTT서비스']) if pd.notna(row.get('OTT서비스')) else None,
                이용비율 = float(row['이용비율']) if pd.notna(row.get('이용비율')) else 0.0,
                OTT_분류 = ott_type_val,
                연령별_분류 = age_class_val, 
            )
            db.merge(ott_data)
            db.commit()
            success += 1
        except Exception as e:
            db.rollback()
            failed += 1
            print(f'적재 실패 - {row.get("OTT서비스")} / {e}')
    
    db.close()

    print(f'[loader] 적재 완료 - 성공: {success:,}건 / 실패: {failed:,}건')

    return {'success': success, 'failed': failed}