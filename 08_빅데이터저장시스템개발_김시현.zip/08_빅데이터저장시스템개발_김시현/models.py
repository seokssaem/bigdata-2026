# =======================================================
# 08_빅데이터저장시스템개발_김시현/models.py
#
# 저장 모델 설계(스키마)
#   기본키 + UNIQUE 제약조건 추가

# 직접 실행되는 파일은 아니다.
#   database.py, loader.py 가 import해서 사용
# =======================================================

from sqlalchemy import Column, Integer, String, Float, UniqueConstraint
from sqlalchemy.orm import declarative_base

Base = declarative_base()

class OttUsage(Base):
    __tablename__ = 'ott_usage'

    id = Column(Integer, primary_key=True, autoincrement=True)

    연도 = Column(String(10), primary_key=True)
    성별 = Column(String(10), nullable=True)
    연령대 = Column(String(20), nullable=True)
    사례수 = Column(Integer, nullable=False)
    OTT서비스 = Column(String(50), nullable=False)
    이용비율 = Column(Float, nullable=False)
    OTT_분류 = Column(String(20))
    연령별_분류 = Column(String(20), nullable=True)

    __table_args__ = (
        UniqueConstraint('연도', '성별', '연령대', '사례수', 'OTT서비스', name='uq_ott_logical_key'),
    )

    def __repr__(self):
        return f'<OttUsage {self.id}: {self.연도} {self.성별} {self.연령대} {self.OTT서비스} >'
    