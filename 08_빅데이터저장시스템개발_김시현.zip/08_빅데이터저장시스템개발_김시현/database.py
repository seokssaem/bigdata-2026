# =======================================================
# 08_빅데이터저장시스템개발_김시현/database.py
#
# PostgreSQL 연결 및 세션 관리
# (DB:subwaydb, 비밀번호:1234)
#
# 수집 과정에서 다 했는데 왜 다시 만드는가???
# --> 원본은 임시 적재였고, 
#       지금이 정식 저장모델 설계 단계
# 
# =======================================================
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Base, OttUsage

DB_URL = 'postgresql://postgres:1234@localhost:5432/ottservicedb'

engine = create_engine(DB_URL, echo=False)

SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

def init_db():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    print('[database] ott_usage 테이블 준비 완료 (연도 기본키)')

def get_session():
    return SessionLocal()

if __name__ == '__main__':
    init_db()