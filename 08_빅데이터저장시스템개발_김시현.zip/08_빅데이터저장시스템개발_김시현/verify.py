# =======================================================================
# 08_빅데이터저장시스템개발_김시현/verify.py
#
#   OTT 서비스 적재 검증 
#       - 필수 컬럼 NULL 여부
#       - 이용비율 범위
#       - OTT 서비스 분류
# 
# =============================================================================
from sqlalchemy import text
from database import engine


OTT_CLASSIFICATION = {'해외', '국내'}

def verify():
    with engine.connect() as conn:
        total = conn.execute(text("SELECT COUNT(*) FROM ott_usage")).scalar()

        null_check = conn.execute(text("""
            SELECT COUNT(*) FILTER (WHERE 연도 IS NULL) AS null_year,
                COUNT(*) FILTER (WHERE 사례수 IS NULL) AS null_count,
                COUNT(*) FILTER (WHERE "OTT서비스" IS NULL) AS null_service,
                COUNT(*) FILTER (WHERE 이용비율 IS NULL) AS null_rate
            FROM ott_usage                                                                                                                                                                    
        """)).fetchone()

        ott_of_range = conn.execute(text("""
            SELECT COUNT(*) FROM ott_usage
            WHERE 이용비율 NOT BETWEEN 0.0 AND 100.0 
        """)).scalar()

        ott_types = conn.execute(text("""
            SELECT DISTINCT "OTT_분류" FROM ott_usage WHERE "OTT_분류" IS NOT NULL
        """)).fetchall()
        
        invalid_ott_type = []
        for t in ott_types:
            if t[0] not in OTT_CLASSIFICATION:
                invalid_ott_type.append(t[0])

    print('==== 적재 검증 결과 ====')
    print(f'전체 건수 : {total:,}')
    print(f'연도 NULL 건수 : {null_check[0]}')
    print(f'사례수 NULL 건수 : {null_check[1]}')
    print(f'OTT서비스 NULL 건수 : {null_check[2]}')
    print(f'이용비율 NULL 건수 : {null_check[3]}')
    print(f'이용비율 범위 이탈 건수 : {ott_of_range}')
    print(f'OTT_분류 이상값 : {invalid_ott_type if invalid_ott_type else "없음"}')

    ok = (sum(null_check) == 0 and ott_of_range == 0 and not invalid_ott_type)
    print(f'검증 결과 : {ok}')
    return ok

if __name__ == '__main__':
    verify()