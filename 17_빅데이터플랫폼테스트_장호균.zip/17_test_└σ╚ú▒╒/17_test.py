from fastapi.testclient import TestClient
from main import app

client = TestClient(app)


# def test_도서검색_정상():
#     response = client.get("/books/search", params={"keyword": "파이썬"})

#     assert response.status_code == 200

#     data = response.json()

#     assert "count" in data
#     assert "results" in data


def test_도서검색_빈값():
    response = client.get("/books/search", params={"keyword": ""})

    assert response.status_code == 400

    assert response.json()["detail"] == "검색어를 입력하세요"