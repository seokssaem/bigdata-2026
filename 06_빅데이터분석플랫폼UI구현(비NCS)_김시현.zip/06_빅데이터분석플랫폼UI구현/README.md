# 연령별 OTT 이용 통계

> index.html + style.css 두 파일로 
OTT 이용 통계
웹페이지 만들기

## 사용데이터 출처
- 공공데이터 포털
    - https://www.data.go.kr/data/15147384/fileData.do

## 🛠️ 2. 구현 기능 요약 (Key Features)
### 🟠 연령별 이용률 대시보드 (Age Statistics Section)

## 🚀 3. 실행 방법
프로젝트 폴더
- index.html
- style.css
- images