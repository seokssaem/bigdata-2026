# ============================================================================
# 09_빅데이터처리시스템개발_김시현/batch_processor.py
#   - "배치 처리(Batch Processor)" 단계 예제 실습
#   - 저장시스템에 이미 적재되어 있는 원본 테이블(ott_usage) 전체를 
#           한 번에 읽어서, 집계 결과 테이블을 새로 만든다.
# ============================================================================
from database import ott_engine, check_required_tables, execute_sql

def create_ott_service_summary() -> None:
    """
    OTT 원본 데이터(ott_usage)를 "OTT서비스 + 연도" 기준으로
    그룹핑하여 서비스별 평균 이용비율 및 총 사례수를 집계하는 테이블을 만든다.
    
    ROUND(AVG("이용비율(%)")::numeric, 2)
        --> AVG 결과값을 numeric 타입으로 변환 후 소수점 둘째 자리까지 반올림 (PostgreSQL 문법)
    """
    execute_sql(
        ott_engine,
        '''
        DROP TABLE IF EXISTS analytics_ott_service_summary;

        CREATE TABLE analytics_ott_service_summary AS
        SELECT
            "OTT서비스" AS ott_service,
            "연도" AS statistic_year,
            "OTT 분류" AS ott_category,
            COUNT(*) AS row_count,
            SUM("사례수") AS total_sample_size,
            ROUND(AVG("이용비율(%)")::numeric, 2) AS avg_usage_ratio
        FROM ottservice_raw
        GROUP BY "OTT서비스", "연도", "OTT 분류";

        CREATE INDEX idx_analytics_ott_service_summary_ratio
        ON analytics_ott_service_summary(avg_usage_ratio DESC);
        '''
    )
    print('[batch] OTT 서비스별 집계 완료: analytics_ott_service_summary')

def run_batch_processing() -> None:
    """
    배치 처리 전체 흐름을 순서대로 실행하는 엔트리포인트 함수

    실행 순서:
        1) check_required_tables() : OTT 원본 테이블 존재 및 적재 여부 확인
        2) create_ott_service_summary() : OTT 서비스별 집계 테이블 생성
    """
    print('[batch] 필수 입력 테이블 확인')
    check_required_tables()
    create_ott_service_summary()
    print('[batch] 배치 처리 완료')

if __name__ == '__main__':
    run_batch_processing()