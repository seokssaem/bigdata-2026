# ============================================================================
# 09_빅데이터처리시스템개발_김시현/event_processor.py
#   - "이벤트처리(Event Processor / CEP)" 예제
#       배치 처리 결과와 원본 데이터를 대상으로 "이상 상황(조건을 만족하는 사건)"을
#       탐지하여 별도의 알림(alert) 테이블에 기록한다.
#
#   - 이벤트 처리는 조건(규칙)을 만족하는 사건을 찾아내는 것이 핵심이다.
#    1) OTT_HIGH_USAGE_ALERT : 특정 서비스의 평균 이용비율이 임계값 이상인 [시장 독점/인기 급증] 이벤트
#    
# ============================================================================
import argparse
from datetime import datetime

from sqlalchemy import text

from config import ALLOWED_OTT_SERVICES, OTT_PLATFORM_GROUPS, OTT_RATIO_MAX, OTT_RATIO_MIN
from database import ott_engine, check_required_tables, execute_sql

def init_ott_alert_table() -> None:
    """
    OTT 서비스 통계 데이터 이상치 및 알림 이벤트를 저장할 테이블을 준비(없으면 생성)
    """
    execute_sql(
        ott_engine,
        """
        CREATE TABLE IF NOT EXISTS analytics_ott_event_alerts (
            id BIGSERIAL PRIMARY KEY,
            event_type VARCHAR(50) NOT NULL,
            ott_service VARCHAR(100),
            statistic_year VARCHAR(20),
            detail TEXT NOT NULL,
            detected_at TIMESTAMP NOT NULL
        );
        """
    )

def detect_high_usage_events(threshold: float) -> None:
    """
    배치 집계 결과에서 특정 서비스의 평균 이용비율(avg_usage_ratio)이
    사용자가 지정한 임계값(threshold) 이상인 경우 "인기 급증/독점 이벤트"로 등록
    """
    execute_sql(
        ott_engine,
        "DELETE FROM analytics_ott_event_alerts WHERE event_type = 'OTT_HIGH_USAGE_ALERT';"
    )
    execute_sql(
        ott_engine,
        """
        INSERT INTO analytics_ott_event_alerts(
            event_type, ott_service, statistic_year, detail, detected_at
        )
        SELECT
            'OTT_HIGH_USAGE_ALERT', ott_service, statistic_year,
            CONCAT('avg_usage_ratio=', avg_usage_ratio, '% (기준값=', :threshold, '%)'),
            :detected_at
        FROM analytics_ott_service_summary
        WHERE avg_usage_ratio >= :threshold;
        """,
        {"threshold": threshold, "detected_at": datetime.now()}
    )
    print(f'[event] OTT 이용률 서비스 탐지 완료 threshold={threshold}%')

def check_ott_summary_ready() -> None:
    """
    이벤트 처리는 배치 처리 결과(analytics_ott_service_summary)를 입력으로 사용하므로
    이 테이블이 먼저 만들어져야 한다. 실행 순서를 알려주는 함수
    """
    try:
        with ott_engine.connect() as conn:
            conn.execute(text("SELECT 1 FROM analytics_ott_service_summary LIMIT 1"))
    
    except Exception as exc:
        raise RuntimeError(
            "analytics_ott_service_summary 테이블이 없습니다."
            "event_processor.py 실행 전에 batch_processor.py를 먼저 실행하세요."
        )

def run_event_processing(ott_threshold: float = 70.0) -> None:
    """OTT 서비스 데이터 이벤트 처리 전체 흐름을 실행하는 엔트리포인트 함수"""
    check_required_tables()
    check_ott_summary_ready()
    init_ott_alert_table()
    detect_high_usage_events(ott_threshold)
    print('[event] 이벤트 처리 완료')

def parse_args() -> argparse.Namespace:
    """
    터미널 입력 매개변수 처리 함수
    """
    parser = argparse.ArgumentParser(description='OTT 서비스 통계 데이터 이상치 및 이벤트 처리')

    parser.add_argument('--ott-threshold', type=float, default=70.0, help='점검할 OTT 서비스 이용비율 임계값 (%)')
    
    return parser.parse_args()

if __name__ == '__main__':
    args = parse_args()
    run_event_processing(ott_threshold=args.ott_threshold)

