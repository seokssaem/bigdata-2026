# ============================================================================
# 09_빅데이터처리시스템개발_김시현/database.py
#   - 프로젝트 전역에서 사용하는 설정값을 모아두는 모듈
#       (비밀번호, DB 접속 정보 등을 코드에 하드 코딩하지 않고, "환경변수"로 분리)
# ============================================================================
from sqlalchemy import create_engine, text

from config import OTT_DB_URL

# ---------------------------------------------------------------------------------------
# DB Engine 생성
# 
# echo=False : 실행되는 SQL을 콘솔에 출력하지 않는다(디버깅 시 True로 바꾸면 유용)
# future=True : SQLAlchemy 2.0 스타일 API를 사용하겠다는 의미
# ---------------------------------------------------------------------------------------
ott_engine = create_engine(OTT_DB_URL, echo=False, future=True)

def table_count(engine, table_name: str) -> int:
    """주어진 테이블의 전체 행(row) 개수를 반환합니다."""

    with engine.connect() as conn:
        return conn.execute(text(f'SELECT COUNT(*) FROM {table_name}')).scalar_one()
    
def check_required_tables() -> None:
    """
    처리를 시작하기 전에 원본 통계 테이블이 존재하고
    데이터가 실제로 적재되어 있는지 점검하는 함수(Fail Fast)
    """
    checks = [
        (ott_engine, "ott_usage", "OTT 서비스 저장시스템 실습 결과가 필요합니다.")
    ]
    for engine, table_name, hint in checks:
        try:
            count = table_count(engine, table_name)
        except Exception as exc:
            raise RuntimeError(f'{table_name} 테이블을 확인할 수 없습니다. {hint}')
        if count == 0:
            raise RuntimeError(f'{table_name} 테이블은 존재하지만 데이터가 없습니다. 저장시스템 적재를 먼저 확인하세요.')

def execute_sql(engine, sql: str, params: dict | None = None) -> None:
    """여러 문장으로 이루어진 SQL 스크립트를 트랜잭션 내에서 한 번에 실행합니다."""
    with engine.begin() as conn:
        statements = [statement.strip() for statement in sql.split(";") if statement.strip()]
        for statement in statements:
            conn.execute(text(statement), params or {})
        