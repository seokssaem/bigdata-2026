# NCS 빅데이터 처리시스템 실습

## OTT 서비스 처리시스템 예제
저장시스템 실습에서 만든 PostgreSQL 테이블을 
이용하여 배치 처리, 실시간 처리, 이벤트 처리 모듈을 
실행하는 예제

### 1. 전제 조건
지난 주 저장 시스템 실습이 완료되어 있어야 한다.

| DB | 테이블 |
| --- | --- |
| `ottservicedb` | `ott_usage` |

### 2. 필요한 라이브러리
```bash
uv add sqlalchemy psycopg2-binary 
```

### 3. 환경변수
기본값은 저장시스템 실습과 같은 비밀번호 `1234`

``` bash 
set OTT_DB_URL= postgresql://postgres:1234@localhost:5432/ottservicedb
```

### 4. 실행 방법

```bash
python pipeline.py 
```

### 5. 결과 테이블

| DB | 결과 테이블 |
| --- | --- |
| `ottservicedb` | `analytics_ott_service_summary`|
| `ottservicedb` | `analytics_ott_event_alerts` |

### 6. 확인 SQL
```sql
SELECT * FROM analytics_ott_service_summary ORDER BY avg_usage_ratio DESC LIMIT 20;
SELECT * FROM analytics_ott_event_alerts ORDER BY detected_at DESC LIMIT 20;
```

### 7. 실습 목표
- 저장시스템은 데이터를 안전하게 저장하는 것이 목표
- 처리시스템은 저장된 데이터를 목적에 맞게 가공하여 새로운 결과를 만드는 것이 목표!

- Spark / Kafka 설치 없이 Python과 PostgreSQL로 처리 로직을 먼저 구현해서 이해~
- 같은 로직을 Spark SQL, Kafka, Flink, Esper, Hadoop, Hive 등 같은 도구로 확장할 수 있다.
