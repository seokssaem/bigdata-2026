# =====================================================================================
# 09_빅데이터처리시스템개발_김시현/pipeline.py 
# =====================================================================================
import batch_processor
import event_processor
from verify_processor import verify
from database import check_required_tables

def run_pipeline() -> None:
    print('[pipeline] 1단계: 원본 입력 데이터 존재 여부 확인')
    check_required_tables()

    print('[pipeline] 2단계: 배치 데이터마트 집계 시작')
    batch_processor.create_ott_service_summary()
    
    print('[pipeline] 3단계: 이벤트 탐지 및 데이터 이상치 검증')
    event_processor.init_ott_alert_table()
    event_processor.detect_high_usage_events(threshold=10.0)

    print('[pipeline] 4단계: 파이프라인 결과 데이터 검증')
    verify()

if __name__ == '__main__':
    run_pipeline()

