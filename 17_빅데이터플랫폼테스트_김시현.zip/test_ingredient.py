import sys
import os

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)


import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

# 1. 루트 엔드포인트 작동 테스트
def test_read_root():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json() == {"message": "냉장고 관리 API 서버가 정상 작동 중입니다."}

# 2. 식재료 등록(POST) 테스트
def test_create_ingredient():
    sample_data = {
        "name":"우유",
        "category": "유제품",
        "quantity": "1팩",
        "purchase_date": "2026-09-01",
        "expiration_date": "2026-09-15",
        "storage_method": "냉장"
    }
    response = client.post("/ingredients", json=sample_data)

    # HTTP 상태 코드가 201(Created) 또는 200인지 검증
    assert response.status_code in [200,201]

    data = response.json()
    assert data["name"] == "우유"
    assert "id" in data

# 3. 식재료 목록 조회(GET) 테스트
def test_get_ingredients():
    response = client.get("/ingredients?skip=0&limit=10")
    assert response.status_code == 200
    assert isinstance(response.json(), list)

def test_create_ingredient_missing_name():
    # 필수 데이터인 "name"(식재료 이름)이 비어있는 잘못된 데이터 전송
    invalid_data = {
        "name": "",  # 혹은 아예 "name" 키를 제외해도 됩니다.
        "category": "유제품",
        "quantity": "1팩",
        "purchase_date": "2026-09-01",
        "expiration_date": "2026-09-15",
        "storage_method": "냉장"
    }
    response = client.post("/ingredients", json=invalid_data)

    assert response.status_code in [400,422]