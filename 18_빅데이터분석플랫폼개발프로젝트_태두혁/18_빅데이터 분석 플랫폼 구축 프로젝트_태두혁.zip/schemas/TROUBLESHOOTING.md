### 여러 컴퓨터에서 이어서 학습할 때 접근 권한이 없어 에러
- **시도**: 학원 컴퓨터로 학습을 시작하고, 집 컴퓨터에서 `resume=True`로 이어서 돌림
- **문제점**: `PermissionError`로 실패
- **원인**: `resume=True`는 이전 학습 시 `args.yaml`에 저장된 절대경로를 그대로 재사용하기 때문에 계정이 바뀌면 그 경로에 접근 권한이 없어 에러 발생
- **해결방법**: `resume=True` 대신, 이전 학습의 가중치 파일 `last.pt`를 새 학습의 시작점으로 불러오는 방식으로 전환


### 컴퓨터마다 MLflow 버전이 달라 학습 이력 API가 실패
- **시도**: 다른 컴퓨터에서 만든 `mlflow.db`를 가져와 학습 이력 탭(`/model/training-history`) 확인
- **문제점**: 학습 이력 API만 500 오류. `Detected out-of-date database schema (found version …, expected …)`가 발생하고, 안내대로 `mlflow db upgrade`를 실행하면 `Can't locate revision identified by '…'`로 다시 실패 (`/health` 등 다른 API는 정상)
- **원인**: MLflow는 버전이 바뀌면 DB 구조 버전도 바뀌는데, DB가 더 새로운 MLflow로 만들어져 이 컴퓨터에 설치된 옛 버전은 그 구조 버전을 알지 못함. 오류 문구의 "out-of-date"만 보고 DB가 옛날 것이라고 판단했지만, 실제로는 설치된 라이브러리가 더 옛날 버전이었음
- **해결방법**: DB를 올리는 대신 이 컴퓨터의 MLflow를 올려 버전을 맞춤 (`uv lock --upgrade-package mlflow` 후 `uv sync`). `uv.lock`, `pyproject.toml`, Docker용 `requirements.txt`의 MLflow 버전을 같은 값으로 맞추고, 다른 컴퓨터에서는 `git pull` 후 `uv sync`. DB를 업그레이드하면 옛 버전에서는 열리지 않으므로 모든 환경의 버전을 먼저 통일하는 것이 안전


### 화면에서는 "API 연결 실패"인데 curl은 정상 (CORS)
- **시도**: React 개발 서버(`localhost:5173`)에서 백엔드(`localhost:8000`)의 API 호출
- **문제점**: 터미널의 curl은 성공하는데 브라우저에서는 요청이 막혀 "API 연결 실패"가 표시됨
- **원인**: 화면(5173)과 API(8000)의 포트가 달라 브라우저가 서로 다른 출처로 보고 CORS 정책으로 차단. curl에는 이 정책이 없음. 또한 영상 요약을 담은 커스텀 헤더(`X-Detection-Summary`)는 서버가 노출을 허용하지 않으면 화면 코드에서 읽을 수 없음
- **해결방법**: 백엔드에 `CORSMiddleware`를 추가해 5173 출처를 허용하고 `expose_headers=["X-Detection-Summary"]` 설정. 에러 응답에도 CORS 헤더가 붙도록 다른 미들웨어보다 나중에(가장 바깥에) 추가. Docker 배포에서는 nginx `/api` 프록시로 같은 출처가 되어 CORS가 필요 없음


### 하나의 요청에 대한 DB 데이터가 부분적으로 저장됨
- **시도**: 하나의 이미지 요청에 대한 `DetectionRequest`와 여러 개의 `Detection` 데이터를 PostgreSQL에 저장
- **문제점**: 하나의 요청에 대한 DB 데이터가 부분적으로만 저장됨
- **원인**: `DetectionRequest`를 저장하고 `commit`한 다음 `Detection` 데이터를 추가로 저장하는 방식이라, 중간에 실패하면 반쪽짜리 데이터가 남음
- **해결방법**: `commit` 대신 `flush`를 사용하고, 저장 과정에서 오류가 발생하면 `rollback()`하도록 구성해 하나의 트랜잭션으로 묶음
