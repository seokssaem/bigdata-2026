import { useState } from "react"
import type { ComponentType } from "react"

import { Sidebar } from "@/components/Sidebar"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TABS } from "@/lib/tabs"
import type { TabKey } from "@/lib/tabs"
import { AlertsPage } from "@/pages/Alerts"
import { DashboardPage } from "@/pages/Dashboard"
import { DetectPage } from "@/pages/Detect"
import { ModelPage } from "@/pages/ModelInfo"
import { TrainingPage } from "@/pages/Training"
import { VideoPage } from "./pages/Video"


const PAGES: Partial<Record<TabKey, ComponentType>> = {
  dashboard: DashboardPage,
  alerts: AlertsPage,
  detect: DetectPage,
  video: VideoPage,
  model: ModelPage,
  training: TrainingPage,
}

export default function App() {
  const [active, setActive] = useState<TabKey>("alerts")
  const current = TABS.find((tab) => tab.key === active)!
  const Page = PAGES[active]


  return (
    <div className="flex min-h-screen bg-background text-foreground">
      <Sidebar active={active} onChange={setActive} />

      <main className="flex-1 p-8">
        <h1 className="text-2xl font-semibold">{current.label}</h1>

        <div className="mt-6">
          {Page ? (
            <Page />
          ) : (
            <Card className="max-w-xl">
              <CardHeader>
                <CardTitle>{current.label}</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                이 탭의 화면은 다음 단계에서 구현합니다.
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  )
}