# 고객 데이터 탐색적 데이터 분석(EDA)


## 1. 데이터 불러오기

전처리가 완료된 **prj_data_cleaned.csv** 파일을 불러와 분석을 진행하였다.

```python
df = pd.read_csv("prj_data_cleaned.csv")
```

다음 함수를 이용하여 데이터의 전체 구조를 확인하였다.

```python
df.shape
df.dtypes
df.describe()
```

또한 수치형 변수와 범주형 변수를 구분하였다.

```python
numeric_cols = df.select_dtypes(include=["int64","float64"]).columns
category_cols = df.select_dtypes(include=["object"]).columns
```

범주형 변수의 빈도를 확인하기 위해 다음 코드를 사용하였다.

```python
df["쿠폰사용여부"].value_counts()
```

### 목적

- 데이터의 행과 열 개수 확인
- 컬럼의 자료형 확인
- 수치형 데이터의 기술통계량 확인
- 수치형 변수와 범주형 변수 분류
- 범주형 변수의 빈도 확인

---

## 2. 단변량(분포) 시각화

수치형 변수의 분포를 확인하기 위해 Histogram을 사용하였다.

```python
sns.histplot(
    data=df,
    x="월평균구매금액",
    kde=True
)
```

범주형 변수의 분포를 확인하기 위해 Countplot을 사용하였다.

```python
sns.countplot(
    data=df,
    x="쿠폰사용여부"
)
```

### 목적

- 수치형 데이터의 분포 확인
- 데이터의 치우침 및 분포 형태 확인
- 범주형 변수의 빈도 비교

### 분석 결과

- 월평균구매금액의 분포를 확인하였다.
- 쿠폰 사용 여부에 따른 데이터 개수를 확인하였다.

---

## 3. 상관관계 및 이변량 분석

수치형 변수 간 상관관계를 확인하기 위해 상관계수를 계산하였다.

```python
corr = df.corr(numeric_only=True)
```

상관관계는 Heatmap으로 시각화하였다.

```python
sns.heatmap(
    corr,
    annot=True,
    cmap="Blues"
)
```

상관관계가 높은 변수는 Scatterplot으로 확인하였다.

```python
sns.scatterplot(
    data=df,
    x="구매횟수",
    y="월평균구매금액"
)
```

범주형 변수와 수치형 변수의 관계는 Boxplot으로 비교하였다.

```python
sns.boxplot(
    data=df,
    x="쿠폰사용여부",
    y="월평균구매금액"
)
```

### 목적

- 변수 간 상관관계 확인
- 상관관계가 높은 변수의 관계 분석
- 그룹별 데이터 분포 비교

### 분석 결과

- 구매횟수와 월평균구매금액의 관계를 확인하였다.
- 쿠폰 사용 여부에 따른 구매금액 분포를 비교하였다.
- 상관관계가 높더라도 반드시 인과관계를 의미하지는 않는다.

---

## 4. 그룹별 비교 분석

쿠폰사용여부를 기준으로 평균 구매금액을 비교하였다.

```python
group = df.groupby("쿠폰사용여부")["월평균구매금액"].mean()
```

Pivot Table을 이용하여 동일한 결과를 확인하였다.

```python
pivot = df.pivot_table(
    values="월평균구매금액",
    index="쿠폰사용여부",
    aggfunc="mean"
)
```

그룹별 평균은 Barplot으로 시각화하였다.

```python
sns.barplot(
    x=group.index,
    y=group.values
)
```

### 목적

- 그룹별 평균 비교
- 고객 특성에 따른 차이 분석
- 데이터 기반 의사결정 지원

---

## 5. 분석 결과(인사이트)

### 인사이트 1

구매횟수가 증가할수록 월평균구매금액도 증가하는 경향을 확인하였다.

### 인사이트 2

쿠폰 사용 여부에 따라 평균 구매금액 차이가 나타났으며, 이를 활용하여 고객 맞춤형 마케팅 전략을 수립할 수 있다.
