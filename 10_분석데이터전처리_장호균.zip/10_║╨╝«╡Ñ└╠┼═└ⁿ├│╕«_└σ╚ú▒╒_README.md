# NCS-분석데이터전처리, 탐색적데이터분석


## 1. 사용 라이브러리

```python
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler
```

---

## 2. 데이터 불러오기

```python
df = pd.read_csv("prj_data.csv")
```

데이터의 구조와 결측치를 확인하였다.

```python
df.info()
df.isnull().sum()
```

---

## 3. 결측치 처리

### 처리 방법

- 결측 비율이 50%를 초과하는 컬럼은 삭제
- 수치형 변수는 평균(또는 중앙값)으로 대체
- 범주형 변수는 최빈값으로 대체

처리 후

```python
df.isnull().sum()
```

을 이용하여 모든 결측치가 제거되었는지 확인하였다.

---

## 4. 이상치 처리

### 사용 변수

- 나이

### 처리 방법

나이(age) 변수에 대해 Boxplot을 이용하여 이상치를 확인하였다.

```python
sns.boxplot(x=df['나이'])
plt.show()
```

이후 IQR(사분위수 범위) 기법을 이용하여 이상치의 하한값과 상한값을 계산하였다.

```python
Q1 = df["나이"].quantile(0.25)
Q3 = df["나이"].quantile(0.75)

IQR = Q3 - Q1

lower = Q1 - 1.5 * IQR
upper = Q3 + 1.5 * IQR
```

```python
df["나이"] = df["나이"].clip(lower, upper)
```

이상치를 제거하면 데이터의 개수가 줄어들 수 있으므로, 데이터 손실을 최소화하기 위해 경계값으로 대체(capping)하는 방법을 사용하였다.

---

## 5. 범주형 변수 인코딩

### One-Hot Encoding

순서가 없는 변수

- 성별
- 거주지역
- 가입경로

```python
df = pd.get_dummies(
    df,
    columns=['성별','거주지역','가입경로'],
    drop_first=True,
    dtype=int
)
```

### Label Encoding

순서가 있는 변수

- 멤버십등급

```python
encoder = LabelEncoder()

df["멤버십등급"] = encoder.fit_transform(df["멤버십등급"])
```

인코딩 전후 데이터의 shape와 컬럼명을 비교하였다.

---

## 6. 파생변수 생성

기존 컬럼을 이용하여 새로운 변수를 생성하였다.

### 생성한 파생변수

- 구매횟수당평균구매금액

생성 코드

```python
df['구매횟수당평균구매금액'] = df['월평균구매금액'] / df['구매횟수']
```

월평균구매금액과 구매횟수를 함께 활용하여 고객이 1회 구매 시 평균적으로 얼마를 구매하는지를 나타내는 새로운 변수를 생성하였다.

이 파생변수는 고객의 소비 패턴을 분석하는 데 활용할 수 있다.
---

## 7. 데이터 스케일링

StandardScaler를 사용하여 수치형 데이터를 표준화하였다.

```python
from sklearn.preprocessing import StandardScaler

scale_cols = [
    '나이',
    '월평균구매금액',
    '구매횟수',
    '리뷰점수',
    '구매횟수당평균구매금액'
]

scaler = StandardScaler()

df[scale_cols] = scaler.fit_transform(df[scale_cols])
```

스케일링 전후 평균과 표준편차를 비교하였다.

```python
df[scale_cols].describe().loc[['mean','std']]
```

---

## 8. 데이터 저장

최종 전처리된 데이터를 저장하였다.

```python
df.to_csv("prj_data_cleaned.csv", index=False)
```